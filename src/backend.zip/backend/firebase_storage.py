import requests

firebase_config={
    "apiKey": "AIzaSyBbDPSCSER7kkgAV0bEDZmHWSZymlKjHUg",
    "authDomain": "todolist-d4473.firebaseapp.com",
    "projectId": "todolist-d4473",
    "storageBucket": "todolist-d4473.appspot.com",
    "messagingSenderId": "781201600864",
    "appId": "1:781201600864:web:81ee4647f5c60499aeee05",
    "measurementId": "G-7LD1FM7V1N"
}